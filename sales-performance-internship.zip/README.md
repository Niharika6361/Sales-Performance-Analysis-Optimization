
# Sales Performance Analysis & Optimization (Internship Project)

This internship-style project analyzes 50,000+ sales transactions using Excel to identify underperforming products and build a Tableau dashboard highlighting optimization opportunities.

## Tools
- Microsoft Excel
- Tableau

## Highlights
- Analyzed 50k+ sales transactions
- Identified underperforming products (~23% revenue impact)
- Built Tableau dashboard for sales optimization insights
